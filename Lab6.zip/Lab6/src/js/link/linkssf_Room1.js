//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Sfloor
    let textBack = document.createTextNode("Regresar");
    let elementBack = document.getElementById('sFloor');
    let aBack = document.createElement("a");

    aBack.appendChild(textBack);
    aBack.href = "s_Floor.html"

    elementBack.appendChild(aBack);


}