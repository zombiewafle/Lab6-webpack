//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Dinning
    let textDinning = document.createTextNode("Ir a la sala familiar");
    let elementDinning = document.getElementById('living');
    let aDinning = document.createElement("a");

    aDinning.appendChild(textDinning);
    aDinning.href = "livingRoom.html"

    elementDinning.appendChild(aDinning);



    //Entry
    let textEntry = document.createTextNode("Ir a la puerta frontal");
    let elementEntry = document.getElementById('entry');
    let aEntry = document.createElement("a");

    aEntry.appendChild(textEntry);
    aEntry.href = "entry.html"

    elementEntry.appendChild(aEntry);


    //Kitchen
    let textKitchen = document.createTextNode("Regresar");
    let elementKitchen = document.getElementById('kitchen');
    let aKitchen = document.createElement("a");

    aKitchen.appendChild(textKitchen);
    aKitchen.href = "kitchen.html"

    elementKitchen.appendChild(aKitchen);
    

}