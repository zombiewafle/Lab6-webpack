window.onload = function(){
    
    let textKitchen = document.createTextNode("Entrar a la casa");
    let elementKitchen = document.getElementById('kitchen');
    let aKitchen = document.createElement("a");

    aKitchen.appendChild(textKitchen);
    aKitchen.href = "kitchen.html"

    elementKitchen.appendChild(aKitchen);


    let textBack = document.createTextNode("Regresar hacia el frente de la casa");
    let elementBack = document.getElementById('start');
    let aBack = document.createElement("a");

    aBack.appendChild(textBack);
    aBack.href = "start.html"

    elementBack.appendChild(aBack);

}