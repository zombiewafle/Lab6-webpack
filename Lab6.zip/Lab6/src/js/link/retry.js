window.onload = function(){
    
    let textRetry = document.createTextNode("Reintentar");
    let elementRetry = document.getElementById('retry');
    let aRetry = document.createElement("a");

    aRetry.appendChild(textRetry);
    aRetry.href = "start.html"

    elementRetry.appendChild(aRetry);

}