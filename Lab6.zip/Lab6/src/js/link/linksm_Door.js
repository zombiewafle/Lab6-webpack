//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Manejo de links de m_Door.html
    let textMDoor = document.createTextNode("Entrar a la casa");
    let elementMDoor = document.getElementById('mDoorEntry');
    let aMDoor = document.createElement("a");

    aMDoor.appendChild(textMDoor);
    aMDoor.href = "entry.html"

    elementMDoor.appendChild(aMDoor);

    console.log("hola");

    //Manejo de links de start.html
    //let textmDoor = document.createTextNode("Entrar a la casa");
    //let elementmDoor = document.getElementById("m_door");
    //let amDoor = document.createElement("a");
//
    //amDoor.appendChild(textmDoor);
    //amDoor.href = "entry.html";
//
    //elementmDoor.appendChild(amDoor);

    //var space = document.createElement("br");

    let textMDoorBack = document.createTextNode("Regresar");
    let elementMDoorBack = document.getElementById('mDoorBack');
    let aMDoorBack = document.createElement("a");

    aMDoorBack.appendChild(textMDoorBack);
    aMDoorBack.href = "start.html"

    //document.body.appendChild(space);
    elementMDoorBack.appendChild(aMDoorBack);

}