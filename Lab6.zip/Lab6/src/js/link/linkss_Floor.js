//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Hallway
    let textHallway = document.createTextNode("Recorrer los pasillos");
    let elementHallway = document.getElementById('hallway');
    let aHallway = document.createElement("a");

    aHallway.appendChild(textHallway);
    aHallway.href = "hallway.html"

    elementHallway.appendChild(aHallway);


    //Sf Room1
    let textRoom1 = document.createTextNode("Entrar al cuarto en el lado izquierdo del pasillo");
    let elementRoom1 = document.getElementById('sfroom1');
    let aRoom1 = document.createElement("a");

    aRoom1.appendChild(textRoom1);
    aRoom1.href = "sf_Room1.html"

    elementRoom1.appendChild(aRoom1);


    //Sf Room1
    let textRoom2 = document.createTextNode("Entrar al cuarto en el lado derecho del pasillo");
    let elementRoom2 = document.getElementById('sfroom2');
    let aRoom2 = document.createElement("a");

    aRoom2.appendChild(textRoom2);
    aRoom2.href = "sf_Room2.html"

    elementRoom2.appendChild(aRoom2);

    //Sf Room1
    let textEntry = document.createTextNode("Regresar");
    let elementEntry = document.getElementById('entry');
    let aEntry = document.createElement("a");

    aEntry.appendChild(textEntry);
    aEntry.href = "entry.html"

    elementEntry.appendChild(aEntry);


}