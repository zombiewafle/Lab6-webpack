window.onload = function(){
    //Sfloor
    let textOut = document.createTextNode("Huir y no volver");
    let elementOut = document.getElementById('out');
    let aOut = document.createElement("a");

    aOut.appendChild(textOut);
    aOut.href = "end.html"

    elementOut.appendChild(aOut);


}