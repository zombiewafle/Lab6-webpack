//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Manejo de links de Index.html
    let textStart = document.createTextNode("Start");
    let elementStart = document.getElementById('startText');
    let aStart = document.createElement("a");

    aStart.appendChild(textStart);
    aStart.href = "start.html"

    elementStart.appendChild(aStart);

    //Manejo de links de start.html
    //let textmDoor = document.createTextNode("Entrar a la casa");
    //let elementmDoor = document.getElementById("m_door");
    //let amDoor = document.createElement("a");
//
    //amDoor.appendChild(textmDoor);
    //amDoor.href = "entry.html";
//
    //elementmDoor.appendChild(amDoor);

    


}