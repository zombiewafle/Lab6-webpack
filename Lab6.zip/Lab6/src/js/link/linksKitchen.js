window.onload = function(){
    
    let textDinning = document.createTextNode("Ir hacia el comedor");
    let elementDinning = document.getElementById('dinning');
    let aDinning = document.createElement("a");

    aDinning.appendChild(textDinning);
    aDinning.href = "diningRoom.html"

    elementDinning.appendChild(aDinning);


    let textBreak = document.createTextNode("Regresar");
    let elementBreak = document.getElementById('b_door');
    let aBreak = document.createElement("a");

    aBreak.appendChild(textBreak);
    aBreak.href = "b_Door.html"

    elementBreak.appendChild(aBreak);

}