//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Sfloor
    let textHallway = document.createTextNode("Regresar");
    let elementHallway = document.getElementById('runBack');
    let aHallway = document.createElement("a");

    aHallway.appendChild(textHallway);
    aHallway.href = "run.html"

    elementHallway.appendChild(aHallway);

    


}