window.onload = function(){
    
    let textInspect = document.createTextNode("Regresar");
    let elementInspect = document.getElementById('inspect');
    let aInspect = document.createElement("a");

    aInspect.appendChild(textInspect);
    aInspect.href = "livingRoom.html"

    elementInspect.appendChild(aInspect);

    
}