window.onload = function(){
    //Manejo de links de Index.html
    let textbDoor = document.createTextNode("Romper la puerta y entrar a la casa");
    let elementbDoor = document.getElementById('bDoor');
    let abDoor = document.createElement("a");

    abDoor.appendChild(textbDoor);
    abDoor.href = "b_Door.html"

    elementbDoor.appendChild(abDoor);


    //Manejo de links de start.html
    let textStart = document.createTextNode("Regresar por el pasillo hacia la puerta frontal");
    let elementStart = document.getElementById('start');
    let aStart = document.createElement("a");

    aStart.appendChild(textStart);
    aStart.href = "start.html"
    console.log("Hello"); //Just a testing for the js file

    elementStart.appendChild(aStart);

    


}