//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Manejo de links de Index.html
    let textStartMDoor = document.createTextNode("Puerta Principal");
    let elementStartMDoor = document.getElementById('m_door');
    let aStartMDoor = document.createElement("a");

    aStartMDoor.appendChild(textStartMDoor);
    aStartMDoor.href = "m_Door.html"

    elementStartMDoor.appendChild(aStartMDoor);

    //Manejo de links de start.html
    //let textmDoor = document.createTextNode("Entrar a la casa");
    //let elementmDoor = document.getElementById("m_door");
    //let amDoor = document.createElement("a");
//
    //amDoor.appendChild(textmDoor);
    //amDoor.href = "entry.html";
//
    //elementmDoor.appendChild(amDoor);


    //Manejo de links de start.html
    let textStartOCorridor = document.createTextNode("Pasillo a un lado");
    let elementStartOCorridor = document.getElementById('o_corridor');
    let aStartOCorridor = document.createElement("a");

    aStartOCorridor.appendChild(textStartOCorridor);
    aStartOCorridor.href = "o_Corridor.html"
    console.log("Hello"); //Just a testing for the js file

    elementStartOCorridor.appendChild(aStartOCorridor);

    
    let textOut = document.createTextNode("Huir");
    let elementOut = document.getElementById('out');
    let aOut = document.createElement("a");

    aOut.appendChild(textOut);
    aOut.href = "aEnding.html"

    elementOut.appendChild(aOut);


}