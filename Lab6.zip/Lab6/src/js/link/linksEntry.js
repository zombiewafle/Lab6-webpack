//Este documento es solamente para manejar los links de los botones y los textos. 

window.onload = function(){
    //Sfloor
    let textFloor = document.createTextNode("Subir las escaleras hacia el segundo nivel");
    let elementFloor = document.getElementById('entrySFloor');
    let aFloor = document.createElement("a");

    aFloor.appendChild(textFloor);
    aFloor.href = "s_Floor.html"

    elementFloor.appendChild(aFloor);


        

    //dinningRoom

    let textD = document.createTextNode("Ir al comedor");
    let elementD = document.getElementById('entryDiningRoom');
    let aD = document.createElement("a");

    aD.appendChild(textD);
    aD.href = "diningRoom.html"

    elementD.appendChild(aD);

    

    //m_Door

    let textMDoor = document.createTextNode("Salir de la casa");
    let elementMDoor = document.getElementById('entrymDoor');
    let aMDoor = document.createElement("a");

    aMDoor.appendChild(textMDoor);
    aMDoor.href = "m_Door.html"
    console.log("Hello"); //Just a testing for the js file

    elementMDoor.appendChild(aMDoor);


    


}