window.onload = function(){
    //Sfloor
    let textFleeing = document.createTextNode("Ir al primer piso y huir");
    let elementFleeing = document.getElementById('fleeing');
    let aFleeing = document.createElement("a");

    aFleeing.appendChild(textFleeing);
    aFleeing.href = "run_Entry.html"

    elementFleeing.appendChild(aFleeing);


}