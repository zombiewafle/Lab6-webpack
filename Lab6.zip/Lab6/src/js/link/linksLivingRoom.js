window.onload = function(){
    
    let textInspect = document.createTextNode("Inspeccionar la sala familiar");
    let elementInspect = document.getElementById('inspect');
    let aInspect = document.createElement("a");

    aInspect.appendChild(textInspect);
    aInspect.href = "inspectingLivingRoom.html"

    elementInspect.appendChild(aInspect);


    let textKitchen = document.createTextNode("Regresar");
    let elementKitchen = document.getElementById('kitchen');
    let aKitchen = document.createElement("a");

    aKitchen.appendChild(textKitchen);
    aKitchen.href = "kitchen.html"

    elementKitchen.appendChild(aKitchen);

}