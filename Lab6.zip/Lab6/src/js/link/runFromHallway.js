window.onload = function(){
    //Sfloor
    let textRunning = document.createTextNode("Continuar huyendo");
    let elementRunning = document.getElementById('run');
    let aRunning = document.createElement("a");

    aRunning.appendChild(textRunning);
    aRunning.href = "run_Outside.html"

    elementRunning.appendChild(aRunning);


}